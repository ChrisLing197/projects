sudo docker build -t django-healthnet .
