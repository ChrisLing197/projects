Dependencies:
    Python 3.4.3
    Django 1.9.1

Initial setup:

python manage.py makemigrations
python manage.py migrate
python create_admin.py
python manage.py runserver

Running:

python manage.py runserver

test liason:
Christian Ling		cxl8338@g.rit.edu

Other files in public_html/Release-2-beta/cross-team-testing/
test_plan_tracker.xlsx
health_net.zip
requirements.docx

